/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */
package net.sourceforge.pmd.cpd;

/**
 * @deprecated Use net.sourceforge.pmd.util.FileFinder instead.
 */
public class FileFinder extends net.sourceforge.pmd.util.FileFinder {
}
